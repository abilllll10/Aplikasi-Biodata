package com.example.aplikasimenumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;
import android.view.View.OnClickListener;



import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    private RecyclerView daftarmenu;
    private ArrayList<menumakanan> listmenu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        daftarmenu = findViewById(R.id.daftarmenu);
        initData();
        daftarmenu.setAdapter(new menumakananAdapter(listmenu));
        daftarmenu.setLayoutManager(new LinearLayoutManager(this));

    }

    private void initData() {
        this.listmenu = new ArrayList<>();
        listmenu.add(new menumakanan("Ayam Bakar",
                "Ayam bakar dengan bumbu khusus membuatnya jadi nikmat dan lezat",
                "Rp 30000",R.drawable.ayambkr));
        listmenu.add(new menumakanan("Gado Gado",
                "Gado gado dengan bumbu kacang yang enak dan lezat",
                "Rp 15000",R.drawable.gado));
        listmenu.add(new menumakanan("Mie Goreng Spesial",
                "Mie goreng dengan cita rasa lokal dengan bumbu lezat dan bergizi",
                "Rp 20000",R.drawable.migor));
        listmenu.add(new menumakanan("Nasi Goreng Ayam",
                "Nasi goreng ayam nikmat,harum dan sedap dengan toping ayam yang enak",
                "Rp 20000",R.drawable.nsgrg));
        listmenu.add(new menumakanan("Soto Kudus",
                "Soto kudus dengan rasa yang enak dipadukan dengan kuah yang gurih dan lezat",
                "Rp 12000",R.drawable.sokus));

    }

}
